import { Component } from '@angular/core';

@Component({
  selector: 'app-hotel-amenties',
  templateUrl: './hotel-amenties.component.html',
  styleUrls: ['./hotel-amenties.component.scss']
})
export class HotelAmentiesComponent {

}
