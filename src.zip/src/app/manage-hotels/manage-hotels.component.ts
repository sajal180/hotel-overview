import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-hotels',
  templateUrl: './manage-hotels.component.html',
  styleUrls: ['./manage-hotels.component.scss']
})
export class ManageHotelsComponent {

}
